'use client';

import { useRef, useState, useEffect, type FormEvent } from 'react';
import reference from './reference-content.json';
import { validateLead, type Lead } from '../lib/validation';
import { CONSENT_KEY, readConsent, saveConsent, applyConsent, trackSavedLead, type Consent } from '../lib/meta-pixel';

const phone = '+358401234567';
const email = 'nimi@yritys.fi';
function Arrow() { return <span aria-hidden="true">↗</span>; }

function ContactForm({onPrivacy}: {onPrivacy: () => void}) {
  const formRef = useRef<HTMLFormElement>(null);
  const requestId = useRef('');
  const pendingRef = useRef(false);
  const [errors,setErrors] = useState<Partial<Record<keyof Lead,string>>>({});
  const [state,setState] = useState<'idle'|'pending'|'success'|'error'>('idle');
  const [message,setMessage] = useState('');
  const [reference,setReference] = useState('');
  const statusRef = useRef<HTMLDivElement>(null);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pendingRef.current || state === 'success') return;
    const form = event.currentTarget;
    const raw = Object.fromEntries(new FormData(form).entries());
    const {values,errors: nextErrors} = validateLead(raw);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) {
      setState('idle');
      form.querySelector<HTMLInputElement>(`[name="${Object.keys(nextErrors)[0]}"]`)?.focus();
      return;
    }
    requestId.current ||= crypto.randomUUID();
    pendingRef.current = true;
    setState('pending'); setMessage('');
    try {
      const res = await fetch('/api/leads', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...values, contact_fax:raw.contact_fax,requestId:requestId.current}),signal:AbortSignal.timeout(20000)});
      const data = await res.json() as {ok?:boolean;errors?:Partial<Record<keyof Lead,string>>;error?:string;reference?:string};
      if (!res.ok || data.ok !== true) {
        if (data.errors) {
          setErrors(data.errors); setState('idle');
          form.querySelector<HTMLInputElement>(`[name="${Object.keys(data.errors)[0]}"]`)?.focus();
          return;
        }
        throw Error(data.error || 'Lähetys ei onnistunut. Yritä hetken kuluttua uudelleen.');
      }
      setReference((data.reference || requestId.current).slice(0,8));
      setState('success');
      trackSavedLead(data.reference || requestId.current);
      requestAnimationFrame(()=>statusRef.current?.focus());
    } catch (err) {
      const failure = err as Error;
      setMessage(failure.name === 'TimeoutError' || failure.name === 'TypeError' ? 'Yhteys katkesi. Tietosi ovat edelleen lomakkeella. Tarkista verkkoyhteys ja yritä uudelleen.' : failure.message);
      setState('error');
    } finally { pendingRef.current = false; }
  }
  return <div className="form-card">
    {state === 'success' ? <div className="success" tabIndex={-1} ref={statusRef} role="status">
      <span className="success-icon" aria-hidden="true">✓</span><p className="eyebrow">PYYNTÖ VASTAANOTETTU</p>
      <h3>Kiitos yhteydenotosta!</h3><p>Pyyntösi on tallennettu. Otan sinuun yhteyttä, niin katsotaan yhdessä yrityksesi tilannetta.</p>
      <p className="small">Soitan numerosta <a href={`tel:${phone}`}>+358 40 123 4567</a>.<br/>Pyynnön tunniste: {reference}</p>
      <a className="text-link" href="#top">Takaisin sivun alkuun <Arrow/></a>
    </div> : <form ref={formRef} onSubmit={submit} noValidate aria-busy={state==='pending'}>
      
      <div className="field"><label htmlFor="company">Yritys</label><input id="company" name="company" autoComplete="organization" required minLength={2} maxLength={120}  aria-invalid={!!errors.company} aria-describedby={errors.company?'company-error':undefined}/>{errors.company&&<p id="company-error" className="field-error">{errors.company}</p>}</div>
      <div className="field"><label htmlFor="email">Sähköposti</label><input id="email" name="email" type="email" inputMode="email" autoComplete="email" required maxLength={160}  aria-invalid={!!errors.email} aria-describedby={errors.email?'email-error':undefined}/>{errors.email&&<p id="email-error" className="field-error">{errors.email}</p>}</div>
      <div className="field"><label htmlFor="phone">Puhelinnumero</label><input id="phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" required maxLength={30} placeholder="040 123 4567 tai +358 40 123 4567" aria-invalid={!!errors.phone} aria-describedby={errors.phone?'phone-error':undefined}/>{errors.phone&&<p id="phone-error" className="field-error">{errors.phone}</p>}</div>
      <div className="field"><label htmlFor="website">Verkkosivun osoite <span className="optional">(valinnainen)</span></label><input id="website" name="website" type="text" inputMode="url" autoComplete="url" maxLength={250}  aria-invalid={!!errors.website} aria-describedby={errors.website?'website-error':undefined}/>{errors.website&&<p id="website-error" className="field-error">{errors.website}</p>}</div>
      <div className="honeypot" aria-hidden="true"><label htmlFor="fax">Faksi</label><input id="fax" name="contact_fax" tabIndex={-1} autoComplete="off"/></div>
      {state === 'error'&&<div role="alert" className="form-error"><strong>Lähetys ei onnistunut.</strong><p>{message}</p><a href={`tel:${phone}`}>Voit myös soittaa: +358 40 123 4567</a></div>}
      <button type="submit" className="button button-primary" disabled={state==='pending'}>{state==='pending'?<><span className="spinner" aria-hidden="true"/>Lähetetään…</>:<>{state==='error'?'Yritä uudelleen':'Pyydä maksuton kartoitus'}</>}</button>
      <p className="form-privacy">Käytän antamiasi tietoja vain yhteydenottoosi vastaamiseen ja mahdollisen yhteistyön selvittämiseen. Lue <button type="button" onClick={onPrivacy} className="inline-button">tietosuojaseloste</button>.</p>
      <noscript><p>Ota yhteyttä sähköpostilla: <a href={`mailto:${email}`}>{email}</a> tai soita <a href={`tel:${phone}`}>+358 40 123 4567</a>. Lomakkeen lähettäminen tarvitsee JavaScriptin.</p></noscript>
    </form>}
  </div>;
}

export default function Landing() {
  const [modal,setModal] = useState<'privacy'|'cookies'|null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const [consent,setConsent] = useState<Consent|null>(null);
  const [consentReady,setConsentReady] = useState(false);
  const [marketingDraft,setMarketingDraft] = useState(false);
  useEffect(()=>{
    const restore=()=>{const saved=readConsent();setConsent(saved);setMarketingDraft(saved?.marketing===true);applyConsent(saved?.marketing===true);setConsentReady(true);};
    restore();
    const sync=(event:StorageEvent)=>{if(event.key===CONSENT_KEY||event.key===null)restore();};
    window.addEventListener('storage',sync);
    return ()=>window.removeEventListener('storage',sync);
  },[]);
  function chooseCookies(marketing:boolean) {
    setConsent(saveConsent(marketing));setMarketingDraft(marketing);setModal(null);
  }
  function openCookies() {setMarketingDraft(consent?.marketing===true);setModal('cookies');}

  useEffect(()=>{
    if (modal && !dialog.current?.open) dialog.current?.showModal();
    if (!modal && dialog.current?.open) dialog.current.close();
  },[modal]);
  const privacy = ()=>setModal('privacy');
  return <div className="lp" onClick={(event)=>{
    const link=(event.target as HTMLElement).closest?.('a[data-policy]');
    if(link){event.preventDefault();if(link.getAttribute('data-policy')==='privacy')setModal('privacy');else openCookies();}
  }}>
    <a className="skip-link" href="#sisalto">Siirry sisältöön</a>
    <main id="sisalto">
      <div dangerouslySetInnerHTML={{__html:reference.beforeContact}}/>
      <section id="yhteydenotto" className="reference-contact" style={{background:'#FFFFFF',padding:'96px 24px'}}>
        <div className="reference-contact-grid" style={{maxWidth:1120,margin:'0 auto',display:'flex',flexWrap:'wrap',gap:56,alignItems:'flex-start'}}>
          <div className="reference-contact-intro" style={{display:'contents'}} dangerouslySetInnerHTML={{__html:reference.contactIntro}}/>
          <ContactForm onPrivacy={privacy}/>
        </div>
      </section>
    </main>
    <div dangerouslySetInnerHTML={{__html:reference.footer}}/>
    <div className="reference-mobile-bar"><a href="#yhteydenotto">Jätä tiedot</a><a href={`tel:${phone}`}><svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>Soita</a></div>
    {consentReady&&!consent&&modal!=='cookies'&&<aside className="cookie-banner" aria-label="Evästevalinnat"><div><h2>Evästeet</h2><p>Meta Pixel mittaa käyntejä ja lomakelähetyksiä suostumuksellasi. <button className="inline-button" type="button" onClick={privacy}>Tietosuojaseloste</button></p></div><div className="cookie-actions"><button type="button" className="cookie-choice" onClick={()=>chooseCookies(false)}>Vain välttämättömät</button><button type="button" className="cookie-choice" onClick={()=>chooseCookies(true)}>Hyväksy</button><button type="button" className="inline-button cookie-customize" onClick={openCookies}>Asetukset</button></div></aside>}
    <dialog ref={dialog} onCancel={()=>setModal(null)} onClick={(e)=>{if(e.target===dialog.current)setModal(null);}} aria-labelledby="dialog-title"><div className="dialog-content"><button className="dialog-close" aria-label="Sulje" onClick={()=>setModal(null)}>✕</button>{modal==='privacy'?<><p className="eyebrow">TIETOJEN KÄSITTELY</p><h2 id="dialog-title">Tietosuojaseloste</h2><p>Päivitetty 3.11.2026.</p><h3>Yhteystiedot</h3><p>Aino Toivonen, Y-tunnus 3424676-2.<br/><a href={`mailto:${email}`}>{email}</a> · +358 40 123 4567</p><h3>Mitä tietoja kerätään ja miksi?</h3><p>Kun pyydät kartoituksen, tallennamme yrityksen nimen, sähköpostiosoitteen, puhelinnumeron sekä mahdollisen verkkosivun osoitteen. Lisäksi tallentuvat lähetysaika ja pyynnön tunniste. Tietoja käytetään yhteydenottopyyntöösi vastaamiseen ja mahdollisen yhteistyön selvittämiseen.</p><h3>Mihin tiedot tallentuvat?</h3><p>Tiedot tallennetaan tämän sivuston suojattuun tietokantaan. Kun sähköpostivälitys on käytössä, ilmoitukset välitetään FormSubmit-palvelulla osoitteeseen admin@esimerkki.fi. Sivuston hosting käyttää OpenAI Sites- ja Cloudflare-palveluita. Palveluntarjoajien käsittely voi tapahtua myös EU/ETA-alueen ulkopuolella.</p><h3>Tietojen säilytys ja omat tietosi</h3><p>Voit pyytää tietojesi tarkistamista, korjaamista tai poistamista ottamalla yhteyttä osoitteeseen <a href={`mailto:${email}`}>{email}</a>. Lomakkeen yhteystietoja ei käytetä uutiskirjeisiin eikä niitä lähetetä Meta-pikselitapahtumien mukana.</p><h3>Mittaus ja evästeet</h3><p>Suostumuksellasi Meta Pixel (tunnus 2077904549527201) lähettää Metalle PageView-tapahtuman sivukäynnistä ja Lead-tapahtuman onnistuneesta yhteydenottolomakkeen tallennuksesta. Meta voi käsitellä esimerkiksi IP-osoitetta, selain- ja laitetietoja, sivun osoitetta sekä evästetunnisteita mainonnan mittaamiseen ja kohdentamiseen. Sivun oma suostumusvalinta säilytetään selaimessa enintään 180 päivää. Voit peruuttaa markkinointisuostumuksen sivun alareunan Evästeasetukset-linkistä. Lomake toimii myös ilman suostumusta. Hostingin kirjautuminen ja tietoturva voivat käyttää toimintaan tarvittavia evästeitä.</p><p>Lisätietoa: <a href="https://www.facebook.com/privacy/policy/" target="_blank" rel="noopener noreferrer">Metan tietosuojakäytäntö</a>.</p></>:<><p className="eyebrow">EVÄSTEASETUKSET</p><h2 id="dialog-title">Evästevalintasi</h2><p>Salli tai estä Metan markkinointiseuranta.</p><div className="cookie-line"><div><strong>Välttämättömät toiminnot</strong><p>Sivun toiminta ja evästevalinnan muistaminen.</p></div><span>Aina käytössä</span></div><div className="cookie-line"><label className="marketing-toggle"><input type="checkbox" checked={marketingDraft} onChange={e=>setMarketingDraft(e.target.checked)}/><span><strong>Markkinointi ja mainonnan mittaus</strong><p>Meta Pixel mittaa käyntejä ja lomakelähetyksiä.</p></span></label></div><div className="cookie-settings-actions"><button className="cookie-choice" type="button" onClick={()=>chooseCookies(false)}>Vain välttämättömät</button><button className="cookie-choice" type="button" onClick={()=>chooseCookies(true)}>Hyväksy</button><button className="button-dark" type="button" onClick={()=>chooseCookies(marketingDraft)}>Tallenna valinnat</button></div></>}</div></dialog>
  </div>;
}
