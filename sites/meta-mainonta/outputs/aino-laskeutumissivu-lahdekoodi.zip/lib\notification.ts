import type { Lead } from './validation';
import { env } from 'cloudflare:workers';
export async function notifyLead(lead: Lead, id: string, origin: string) {
  if (['localhost','127.0.0.1','[::1]'].includes(new URL(origin).hostname)) return 'local_test';
  if (env.FORM_EMAIL_ENABLED !== 'true') return 'disabled';
  try {
    const res = await fetch('https://formsubmit.co/ajax/admin@esimerkki.fi', {
      method:'POST',
      headers:{'Content-Type':'application/json','Accept':'application/json','Referer':origin+'/'},
      body:JSON.stringify({
        _subject:'Uusi kartoituspyyntö – '+lead.company,
        _template:'table',_captcha:'false',_url:origin+'/',
        email:lead.email, Yritys:lead.company, Puhelinnumero:lead.phone,
        Verkkosivu:lead.website || 'Ei ilmoitettu', Tunniste:id,
        Hallinta:origin+'/yhteydenotot'
      }),
      signal:AbortSignal.timeout(8000)
    });
    const data = await res.json() as {success?:boolean|string;message?:string};
    if (!res.ok || (data.success !== true && data.success !== 'true')) return 'failed';
    return /activat|confirm|verif/i.test(data.message || '') ? 'activation_required' : 'accepted';
  } catch { return 'failed'; }
}
