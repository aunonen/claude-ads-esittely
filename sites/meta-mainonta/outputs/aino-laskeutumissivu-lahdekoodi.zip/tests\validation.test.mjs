import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateLead } from '../lib/validation.ts';
const valid = {company:'Esimerkki Oy',email:'nimi@example.com',phone:'+358 40 123 4567',website:'yritys.fi'};
test('Accepts Finnish contact details and a website without a protocol',()=>{
  const r=validateLead({...valid,company:'  Esimerkki Oy  '});
  assert.deepEqual(r.errors,{});assert.equal(r.values.website,'https://yritys.fi');assert.equal(r.values.company,'Esimerkki Oy');
});
test('Rejects malformed contact details and unsafe website schemes',()=>{
  const r=validateLead({...valid,company:' ',email:'ei-osoite',phone:'abc123',website:'javascript:alert(1)'});
  for(const field of ['company','email','phone','website']) assert.ok(r.errors[field]);
});
test('Website is optional; oversized and non-string input is rejected',()=>{
  assert.deepEqual(validateLead({...valid,website:''}).errors,{});
  const r=validateLead({...valid,company:'x'.repeat(121),email:{},phone:null});
  assert.ok(r.errors.company);assert.ok(r.errors.email);assert.ok(r.errors.phone);
});
