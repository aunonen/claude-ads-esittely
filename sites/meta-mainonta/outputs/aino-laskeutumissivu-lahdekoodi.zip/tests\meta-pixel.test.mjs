import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPixelTracker,META_PIXEL_ID} from '../lib/meta-pixel-core.ts';
test('No network loader or events before consent or after rejection',async()=>{
  let loads=0;const events=[];
  const t=createPixelTracker(async()=>{loads++;return (...args)=>events.push(args);});
  t.trackLead('unconsented');await t.setConsent(false);t.trackLead('rejected');
  assert.equal(loads,0);assert.deepEqual(events,[]);
});
test('Initializes the requested pixel once and deduplicates saved leads',async()=>{
  const events=[];let loads=0;
  const t=createPixelTracker(async()=>{loads++;return (...args)=>events.push(args);});
  await t.setConsent(true);await t.setConsent(true);
  t.trackLead('saved-1');t.trackLead('saved-1');
  assert.equal(loads,1);
  assert.equal(events.filter(x=>x[0]==='init'&&x[1]===META_PIXEL_ID).length,1);
  assert.equal(events.filter(x=>x[1]==='PageView').length,1);
  assert.deepEqual(events.filter(x=>x[1]==='Lead'),[['track','Lead',{}, {eventID:'lead-saved-1'}]]);
});
test('Revoking consent while the script loads drops queued conversions',async()=>{
  const events=[];let finish;
  const t=createPixelTracker(()=>new Promise(resolve=>{finish=resolve;}));
  const loading=t.setConsent(true);t.trackLead('pending');await t.setConsent(false);
  finish((...args)=>events.push(args));await loading;t.trackLead('revoked');
  assert.deepEqual(events,[['consent','revoke']]);
});
test('Consent can be restored, without backfilling rejected conversions',async()=>{
  const events=[];const t=createPixelTracker(async()=>(...args)=>events.push(args));
  await t.setConsent(true);await t.setConsent(false);t.trackLead('no');await t.setConsent(true);t.trackLead('yes');
  assert.equal(events.filter(x=>x[1]==='PageView').length,1);
  assert.deepEqual(events.filter(x=>x[1]==='Lead').map(x=>x[3].eventID),['lead-yes']);
});
test('Blocked tracking cannot prevent a saved lead from showing success',async()=>{
  const t=createPixelTracker(async()=>{throw Error('blocked');});
  await t.setConsent(true);assert.doesNotThrow(()=>t.trackLead('saved'));
});
