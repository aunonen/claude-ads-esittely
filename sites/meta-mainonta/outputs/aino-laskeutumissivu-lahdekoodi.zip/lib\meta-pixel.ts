import { createPixelTracker, type PixelCall } from './meta-pixel-core';
export const CONSENT_KEY = 'aino-cookie-consent-v1';
export type Consent = {version:1;marketing:boolean;expiresAt:number};
type Fbq = PixelCall & {callMethod?:PixelCall;queue:unknown[][];push?:Fbq;loaded:boolean;version:string};
type PixelWindow = Window & {fbq?:Fbq;_fbq?:Fbq};

function loadPixel(): Promise<PixelCall> {
  return new Promise((resolve,reject)=>{
    const win = window as PixelWindow;
    if (win.fbq?.callMethod) { resolve(win.fbq); return; }
    const fbq: Fbq = win.fbq || Object.assign(function(...args:unknown[]) {
      if (fbq.callMethod) fbq.callMethod(...args); else fbq.queue.push(args);
    }, {queue:[] as unknown[][],loaded:true,version:'2.0'});
    fbq.push = fbq;
    win.fbq = fbq;
    win._fbq ||= fbq;
    const script = document.createElement('script');
    script.id = 'aino-meta-pixel';
    script.async = true;
    script.src = 'https://connect.facebook.net/en_US/fbevents.js';
    script.onload = () => resolve(fbq);
    script.onerror = () => {
      script.remove();
      if (!fbq.callMethod) { delete win.fbq; delete win._fbq; }
      reject(new Error('Meta Pixel unavailable'));
    };
    document.head.appendChild(script);
  });
}
const tracker = createPixelTracker(loadPixel);
export function readConsent(): Consent | null {
  try {
    const data = JSON.parse(localStorage.getItem(CONSENT_KEY) || 'null');
    if (data?.version===1 && typeof data.marketing==='boolean' && data.expiresAt>Date.now()) return data;
  } catch { /* Storage may be disabled; ask again next visit. */ }
  return null;
}
function clearMetaCookies() {
  const hostname = location.hostname;
  const parts = hostname.split('.');
  const domains = ['',...parts.map((_,i)=>'.'+parts.slice(i).join('.'))];
  for (const name of ['_fbp','_fbc']) for (const domain of domains) {
    document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax${domain?'; domain='+domain:''}${location.protocol==='https:'?'; Secure':''}`;
  }
}
export function applyConsent(allowed:boolean) {
  void tracker.setConsent(allowed);
  if (!allowed && typeof document!=='undefined') clearMetaCookies();
}
export function saveConsent(marketing:boolean): Consent {
  const choice: Consent={version:1,marketing,expiresAt:Date.now()+180*24*60*60*1000};
  try { localStorage.setItem(CONSENT_KEY,JSON.stringify(choice)); } catch { /* Session choice still applies. */ }
  applyConsent(marketing);
  return choice;
}
export function trackSavedLead(id:string) { tracker.trackLead(id); }
