export const META_PIXEL_ID = '2077904549527201';
export type PixelCall = (...args: unknown[]) => void;

// Loader injection keeps consent/conversion tests isolated from Meta's network.
export function createPixelTracker(load: () => Promise<PixelCall>) {
  let allowed = false;
  let pixel: PixelCall | null = null;
  let loading: Promise<void> | null = null;
  let initialized = false;
  let pageViewed = false;
  const pending = new Set<string>();
  const sent = new Set<string>();
  function flush() {
    if (!allowed || !pixel) return;
    try {
      pixel('consent', 'grant');
      if (!initialized) {
        pixel('set', 'autoConfig', false, META_PIXEL_ID);
        pixel('init', META_PIXEL_ID);
        initialized = true;
      }
      if (!pageViewed) { pixel('track', 'PageView'); pageViewed = true; }
      for (const id of pending) {
        if (!sent.has(id)) {
          pixel('track', 'Lead', {}, {eventID: 'lead-' + id});
          sent.add(id);
        }
        pending.delete(id);
      }
    } catch { /* A blocked tracker must never break the contact form. */ }
  }
  return {
    setConsent(value: boolean) {
      allowed = value;
      if (!value) {
        pending.clear();
        try { pixel?.('consent', 'revoke'); } catch { /* Optional tracking. */ }
        return Promise.resolve();
      }
      if (pixel) { flush(); return Promise.resolve(); }
      if (!loading) {
        loading = load().then(result => {
          pixel = result;
          if (allowed) flush(); else pixel('consent', 'revoke');
        }).catch(() => { loading = null; });
      }
      return loading;
    },
    trackLead(id: string) {
      if (!allowed || !id || sent.has(id)) return;
      pending.add(id);
      flush();
    }
  };
}
