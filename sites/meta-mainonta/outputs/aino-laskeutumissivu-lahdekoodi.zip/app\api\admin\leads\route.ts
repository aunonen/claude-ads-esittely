import { isAdmin } from '../../../../lib/admin';
import { getDb } from '../../../../db/index';
import { leads } from '../../../../db/schema';
import { eq } from 'drizzle-orm';
import { notifyLead } from '../../../../lib/notification';
const reply = (body:object,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(request:Request) {
  if (request.headers.get('origin')!==new URL(request.url).origin) return reply({error:'Virheellinen pyyntö.'},403);
  if (!await isAdmin()) return reply({error:'Ei käyttöoikeutta.'},403);
  if (Number(request.headers.get('content-length')||0)>1024) return reply({error:'Virheellinen pyyntö.'},413);
  try {
    const {id,action}=await request.json() as {id?:unknown;action?:unknown};
    if (typeof id!=='string'||id.length>50||typeof action!=='string'||!['delete','handled','notify'].includes(action)) return reply({error:'Virheellinen pyyntö.'},400);
    const db=getDb(); const row=await db.select().from(leads).where(eq(leads.id,id)).get();
    if (!row) return reply({error:'Pyyntöä ei löydy.'},404);
    if (action==='delete') {await db.delete(leads).where(eq(leads.id,id)); return reply({ok:true});}
    const updated=action==='handled'?{status:'handled'}:{notificationStatus:await notifyLead(row,id,new URL(request.url).origin)};
    await db.update(leads).set(updated).where(eq(leads.id,id));return reply({ok:true,updated});
  }catch{return reply({error:'Toiminto epäonnistui. Yritä uudelleen.'},503);}
}
