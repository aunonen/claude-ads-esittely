'use client';
import { useState } from 'react';
type Entry = {id:string;company:string;email:string;phone:string;website:string;createdAt:number;status:string;notificationStatus:string};
export default function Inbox({initial}:{initial:Entry[]}) {
  const [rows,setRows] = useState(initial);
  const [error,setError] = useState('');
  const [busy,setBusy] = useState('');
  async function action(id:string,action:string) {
    if (busy) return;
    if(action==='delete'&&!confirm('Poistetaanko yhteydenotto pysyvästi tietokannasta? Sähköpostikopiota tämä ei poista.')) return;
    setBusy(id);setError('');
    try {
      const r = await fetch('/api/admin/leads',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,action})});
      const result = await r.json() as {error?:string;updated?:Partial<Entry>};if (!r.ok) throw Error(result.error || 'Toiminto epäonnistui.');
      setRows(action==='delete'?rows.filter(x=>x.id!==id):rows.map(x=>x.id===id?{...x,...result.updated}:x));
    }catch(e){setError((e as Error).message);}finally{setBusy('');}
  }
  return <main className="container admin"><a className="text-link" href="/">← Laskeutumissivu</a><h1 style={{marginTop:35}}>Yhteydenotot</h1><p className="admin-intro">Uusimmat 200 pyyntöä. Ilmoitusten vastaanottaja: admin@esimerkki.fi. FormSubmitin aktivointi täytyy vahvistaa sähköpostista ennen kuin välitys toimii.</p><a className="text-link" href="/yhteydenotot">Päivitä lista ↻</a>{error&&<p role="alert" className="form-error">{error}</p>}<div className="lead-list" style={{marginTop:30}}>{rows.length===0?<p>Ei vielä yhteydenottoja.</p>:rows.map(x=><article className="lead-card" key={x.id}><p className="small">{new Date(x.createdAt).toLocaleString('fi-FI',{timeZone:'Europe/Helsinki'})} · {x.status==='new'?'Uusi':'Käsitelty'}</p><h2>{x.company}</h2><p><a href={`mailto:${x.email}`}>{x.email}</a><br/><a href={`tel:${x.phone}`}>{x.phone}</a>{x.website&&<><br/><a href={x.website} target="_blank" rel="noopener noreferrer">{x.website}</a></>}</p><p className="small">Sähköpostivälitys: {({disabled:'ei käytössä',local_test:'paikallinen testi — ei sähköpostia',pending:'odottaa',failed:'epäonnistui — pyyntö tallessa',activation_required:'odottaa sähköpostin aktivointia',accepted:'välittäjä vastaanotti; tarkista postilaatikko'} as Record<string,string>)[x.notificationStatus] || x.notificationStatus}</p><div className="lead-actions"><button disabled={!!busy} onClick={()=>action(x.id,'handled')}>Merkitse käsitellyksi</button><button disabled={!!busy} onClick={()=>action(x.id,'notify')}>Lähetä ilmoitus uudelleen</button><button disabled={!!busy} onClick={()=>action(x.id,'delete')}>Poista</button></div></article>)}</div></main>;
}
