import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
const base='http://127.0.0.1:5173';
const send=(data,origin=base)=>fetch(base+'/api/leads',{method:'POST',headers:{'Content-Type':'application/json',Origin:origin},body:JSON.stringify(data)});
test('rejects cross-origin posts, invalid fields and unauthorized inbox access',async()=>{
  assert.equal((await send({},'https://unrelated.example')).status,403);
  const invalid=await send({}); assert.equal(invalid.status,422);assert.ok((await invalid.json()).errors.email);
  const denied=await fetch(base+'/api/admin/leads',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({id:randomUUID(),action:'delete'})});
  assert.equal(denied.status,403);
});
test('saves a request, accepts a safe retry, and limits repeat enquiries',async()=>{
  const data={company:'Paikallinen API-testi',email:`local-${randomUUID()}@example.invalid`,phone:'0401234567',website:'esimerkki.fi',requestId:randomUUID()};
  const first=await send(data);assert.equal(first.status,201);assert.equal((await first.json()).ok,true);
  const retry=await send(data);assert.equal(retry.status,200);assert.equal((await retry.json()).reference,data.requestId);
  for(let i=0;i<2;i++) assert.equal((await send({...data,requestId:randomUUID()})).status,201);
  assert.equal((await send({...data,requestId:randomUUID()})).status,429);
});
