import { env } from 'cloudflare:workers';
import { getDb } from '../../../db/index';
import { leads } from '../../../db/schema';
import { eq } from 'drizzle-orm';
import { validateLead, privacyVersion } from '../../../lib/validation';
import { notifyLead } from '../../../lib/notification';
const response = (body: object, status = 200) => Response.json(body, {status, headers: {'Cache-Control': 'no-store'}});
export async function POST(request: Request) {
  const url = new URL(request.url);
  if (request.headers.get('origin') !== url.origin || request.headers.get('sec-fetch-site') === 'cross-site') return response({error:'Päivitä sivu ja yritä uudelleen.'},403);
  if (!request.headers.get('content-type')?.includes('application/json')) return response({error:'Virheellinen pyyntö.'},415);
  if (Number(request.headers.get('content-length') || 0) > 8192) return response({error:'Pyyntö on liian suuri.'},413);
  let raw: unknown;
  try { const body = await request.text(); if (body.length > 8192) return response({error:'Pyyntö on liian suuri.'},413); raw = JSON.parse(body); } catch { return response({error:'Virheellinen pyyntö.'},400); }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return response({error:'Virheellinen pyyntö.'},400);
  const data = raw as Record<string, unknown>;
  if (data.contact_fax) return response({error:'Lähetys ei onnistunut. Päivitä sivu ja yritä uudelleen.'},400);
  const {values, errors} = validateLead(data);
  if (Object.keys(errors).length) return response({errors},422);
  if (typeof data.requestId !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(data.requestId)) return response({error:'Päivitä sivu ja yritä uudelleen.'},400);
  if (!env.DB) return response({error:'Yhteydenottolomake on tilapäisesti pois käytöstä. Yritä myöhemmin uudelleen.'},503);
  try {
    const db = getDb();
    const prior = await db.select().from(leads).where(eq(leads.id, data.requestId)).get();
    if (prior) return response({ok:true, reference:data.requestId});
    const since = Date.now() - 3600_000;
    const recent = await env.DB.prepare('SELECT COUNT(*) AS n FROM leads WHERE email = ? AND created_at > ?').bind(values.email.toLowerCase(),since).first<{n:number}>();
    if ((recent?.n || 0) >= 3) return response({error:'Olet jo lähettänyt yhteydenottopyynnön. Odota hetki ennen uutta lähetystä.'},429);
    const inserted = await db.insert(leads).values({id:data.requestId, ...values,email:values.email.toLowerCase(),createdAt:Date.now(),privacyVersion}).onConflictDoNothing().returning({id:leads.id});
    if (inserted.length) {
      const notificationStatus = await notifyLead(values,data.requestId,url.origin);
      await db.update(leads).set({notificationStatus}).where(eq(leads.id,data.requestId));
    }
    return response({ok:true,reference:data.requestId},201);
  } catch { return response({error:'Lähetys ei onnistunut. Tietosi ovat yhä lomakkeella. Yritä hetken kuluttua uudelleen.'},503); }
}
