export const privacyVersion = '2026-11-03';
export type Lead = { company: string; email: string; phone: string; website: string };
export function validateLead(input: Record<string, unknown>) {
  const values: Lead = { company: '', email: '', phone: '', website: '' };
  for (const key of Object.keys(values) as (keyof Lead)[]) values[key] = typeof input[key] === 'string' ? (input[key] as string).trim() : '';
  const errors: Partial<Record<keyof Lead, string>> = {};
  if (values.company.length < 2 || values.company.length > 120) errors.company = 'Kirjoita yrityksen nimi (2–120 merkkiä).';
  if (values.email.length > 160 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) errors.email = 'Tarkista sähköpostiosoite, esim. nimi@yritys.fi.';
  if (!/^[+\d\s()\-]+$/.test(values.phone) || values.phone.replace(/\D/g, '').length < 7 || values.phone.replace(/\D/g, '').length > 15 || values.phone.length > 30) errors.phone = 'Kirjoita puhelinnumero suuntanumeroineen, esim. 040 123 4567.';
  if (values.website) {
    if (!/^https?:\/\//i.test(values.website)) values.website = 'https://' + values.website;
    try { const u = new URL(values.website); if (!['http:', 'https:'].includes(u.protocol) || !u.hostname.includes('.') || u.username || u.password || values.website.length > 250) throw Error(); }
    catch { errors.website = 'Tarkista verkkosivun osoite, esim. yritys.fi.'; }
  }
  return {values, errors};
}
