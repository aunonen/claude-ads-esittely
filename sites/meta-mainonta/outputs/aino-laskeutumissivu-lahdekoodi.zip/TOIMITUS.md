# Aino Toivonen — laskeutumissivu

Lähde: käyttäjän toimittama `Meta-mainonnan laskeutumissivu.html`. Alkuperäinen tiedosto on säilytetty muuttumattomana Downloads-kansiossa. Sen erilliset työpöytä-, mobiili- ja lomaketilaluonnokset on toteutettu yhdeksi sivuksi.

## Yhteystiedot

- Aino Toivonen · Y-tunnus 3424676-2
- +358 40 123 4567 · nimi@yritys.fi
- Lomakkeiden ilmoitukset: admin@esimerkki.fi

## Toiminta

Lomake tallentaa tiedot palvelimen D1-tietokantaan. Onnistuminen näytetään vasta tallennuksen jälkeen. Välitys käyttää FormSubmitin AJAX-rajapintaa. Vastaanottajan on vahvistettava sähköpostin aktivointilinkki; ennen vahvistusta sähköpostitoimitus ei ole valmis. Välittäjän hyväksyntä ei todista viestin saapumista postilaatikkoon.

`/yhteydenotot` näyttää tallennetut pyynnöt vain ChatGPT-kirjautumiselle, jonka sähköposti on admin@esimerkki.fi. Sivulla voi merkitä pyynnön käsitellyksi, uusia sähköposti-ilmoituksen ja poistaa pyynnön tietokannasta. Sähköpostikopiot poistetaan erikseen Gmailista. Lista näyttää 200 uusinta pyyntöä.

Lomake tarkistaa tiedot sekä selaimessa että palvelimella, estää saman pyynnön kaksinkertaisen tallennuksen ja rajoittaa samasta sähköpostista saapuvia uusia pyyntöjä. Paikallinen testipalvelin ei lähetä sähköposti-ilmoituksia.

Sivulla on Meta Pixel 2077904549527201. Se ladataan vain markkinointisuostumuksen jälkeen; PageView lähetetään kerran sivukäynnillä ja Lead vasta palvelimen vahvistaman lomaketallennuksen jälkeen. Lomakkeen yhteystietoja ei lähetetä pikselille. Evästeasetuksista voi peruuttaa suostumuksen, mikä estää uudet tapahtumat ja poistaa sivuston käytettävissä olevat _fbp- ja _fbc-evästeet. Sivulla ei ole suostumuksen ohittavaa noscript-seurantakuvaa. Fontit ovat paikallisia ja niiden lisenssi on `public/fonts/LICENSE.txt`-tiedostossa. Käyttäjän toimittama omakuva on sivun aloitusosassa ja tekijäesittelyssä. Kuvasta on tehty kevyet 480 ja 960 pikselin WebP-versiot; alkuperäinen kuvatiedosto on säilytetty muuttumattomana.

## Käynnistys ja tarkistukset

```text
npm run dev
npx tsc --noEmit
node --experimental-strip-types --test tests/validation.test.mjs
node --test tests/api.test.mjs
```

API-testi edellyttää paikallista palvelinta ja alustettua paikallista D1-tietokantaa. Testitiedot ovat vain paikallisessa tietokannassa. Tuotantoon ei kopioida testitietokantaa.

Julkaisun sivustotunnus ja D1-sidonta ovat `.openai/hosting.json`-tiedostossa. Uusi Sites-julkaisu on oletuksena yksityinen. Julkinen mainosliikenne edellyttää sivuston näkyvyyden vaihtamista julkiseksi. Hakukoneindeksointi on pois päältä tässä esikatseluversiossa.

## HTML-vastaavuus

Ulkoasu ja tekstit on palautettu käyttäjän alkuperäisen HTML:n mukaisiksi. Vertailun tulokset ja tarkoitukselliset erot on kirjattu `VERTAILU.md`- ja `VERTAILU.json`-tiedostoihin.

Pikselin suostumus-, peruutus-, latauskilpa- ja tuplalähetyslogiikka testataan komennolla `node --experimental-strip-types --test tests/meta-pixel.test.mjs`. Nämä testit eivät lähetä tapahtumia Metalle. Meta Events Managerin vastaanotto on tarkistettava erikseen.
