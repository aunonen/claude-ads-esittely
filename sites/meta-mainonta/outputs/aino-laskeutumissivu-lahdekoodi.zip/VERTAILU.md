# Vertailu alkuperäiseen HTML:ään

Vertailulähde: käyttäjän toimittama `Meta-mainonnan laskeutumissivu.html`, jonka sisältämät työpöytä- ja mobiililuonnokset purettiin lukemista varten. Alkuperäistä tiedostoa ei ole muutettu.

Alkuperäisen työpöytäluonnoksen kuuden osion rakenne, tekstit ja inline-tyylit palautettiin. 1440 pikselin näyttöleveydellä kaikkien kuuden osion sijainti, leveys ja korkeus vastasivat selaimessa alkuperäistä. Aloitusotsikon ja leipätekstien fonttikoot ja mitat vastasivat myös alkuperäistä.

Palautetut osiot: aloitus, kolme vaihetta, hinnoittelu, tekijäesittely, viisi UKK-kysymystä ja yhteydenotto. Edellisen toteutuksen lisätyt otsikot, markkinointitekstit, navigaatio ja ylimääräinen UKK-kysymys poistettiin. Mobiilin yläpalkki ja Jätä tiedot / Soita -alapalkki perustuvat HTML:n mobiililuonnokseen. Mobiili tarkistettiin 390 pikselin leveydellä; vaakasuuntaista ylivuotoa ei ollut.

Tarkoitukselliset muutokset: omakuvan paikat täytettiin käyttäjän kuvalla; yhteystietojen paikkamerkit täytettiin käyttäjän tiedoilla; kehitysversion keltainen huomautus ja kuvan paikkamerkkiohjeet poistettiin; lomakkeeseen lisättiin oikea tallennus, validointi ja lähetyksen tilat. Tietosuojalinkit avaavat toimivan dialogin. Meta Pixeliä ei ole lisätty, joten luonnoksen valinnaisten evästeiden suostumusbänneriä ei näytetä. Evästeasetukset kertovat nykyisen tilanteen.

Sivu säilyy yksityisenä. FormSubmitin sähköpostitoimituksen aiempi palvelinvirhe on edelleen erillinen avoin asia; tämä vertailukorjaus ei muuta sähköpostivälitystä.

Yksityiskohtaiset vertailutiedot: `VERTAILU.json`.

Käyttäjän 1.11.2026 pyytämä poikkeus: tekijäesittelyn kuva on muutettu 112 × 112 pikselin pyöreäksi kuvaksi. Aloitusosan kuva säilyy ennallaan. Aiempi työpöydän mittavertailu kuvaa tätä muutosta edeltävää versiota.

Käyttäjän 2.11.2026 toimittama uusi tarjous: tekstit päivitetty tulospohjaiseen malliin (mainosbudjetti + kriteerit täyttävät tarjouspyynnöt), hinnoittelutaulukko uusittu ja UKK:hon lisätty tarjouspyynnön määritelmä sekä laskutus. Alkuperäisen HTML:n tekstivertailu kuvaa tätä muutosta edeltävää versiota.

Käyttäjän 3.11.2026 pyytämä Meta Pixel 2077904549527201 lisätty suostumuksen taakse. Alkuperäisen lomaketilaluonnoksen mukainen evästevalinta on nyt toiminnassa. Lead-tapahtuma sidotaan onnistuneeseen palvelintallennukseen.
