import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const leads = sqliteTable('leads', {
  id: text('id').primaryKey(),
  company: text('company').notNull(),
  email: text('email').notNull(),
  phone: text('phone').notNull(),
  website: text('website').notNull().default(''),
  createdAt: integer('created_at').notNull(),
  status: text('status').notNull().default('new'),
  notificationStatus: text('notification_status').notNull().default('pending'),
  privacyVersion: text('privacy_version').notNull()
});
