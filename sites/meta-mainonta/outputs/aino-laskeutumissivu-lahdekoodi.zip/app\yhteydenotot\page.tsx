import { isAdmin } from '../../lib/admin';
import { getDb } from '../../db/index';
import { leads } from '../../db/schema';
import { desc } from 'drizzle-orm';
import Inbox from './inbox';
export const dynamic = 'force-dynamic';
export default async function Page() {
  if (!await isAdmin()) return <main className="container admin"><a className="text-link" href="/">← Takaisin sivulle</a><h1 style={{marginTop:35}}>Yhteydenottojen hallinta</h1><p className="admin-intro">Hallinta on rajattu osoitteelle admin@esimerkki.fi. Kirjaudu sitä vastaavalla ChatGPT-tilillä.</p><a className="button button-dark" href="/signin-with-chatgpt?return_to=%2Fyhteydenotot" target="_top">Kirjaudu ChatGPT:llä ↗</a></main>;
  try {
    const rows = await getDb().select().from(leads).orderBy(desc(leads.createdAt)).limit(200);
    return <Inbox initial={rows}/>;
  } catch {
    return <main className="container admin"><h1>Yhteydenotot</h1><p className="admin-intro">Tietokantaan ei juuri nyt saada yhteyttä. Yritä hetken kuluttua uudelleen.</p><a className="button button-dark" href="/yhteydenotot">Yritä uudelleen</a></main>;
  }
}
