declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    FORM_EMAIL_ENABLED?: string;
  }
}
