import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  metadataBase: new URL('https://esimerkki.fi'),
  title: 'Meta-mainontaa palveluyrityksille | Aino Toivonen',
  description: 'Facebook- ja Instagram-mainonta yrityksesi aidoista työkuvista. Maksat vain mainosbudjetin ja sovitun hinnan kriteerit täyttävistä tarjouspyynnöistä. Ei kuukausi- tai aloitusmaksua.',
  robots: { index: false, follow: false },
  openGraph: { title: 'Lisää tarjouspyyntöjä omalta toiminta-alueeltasi.', description: 'Meta-mainontaa suomalaisille palveluyrityksille. Aino Toivonen.', locale: 'fi_FI', type: 'website' },
  icons: { icon: '/favicon.svg' }
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="fi"><body>{children}</body></html>;
}
